<?php
require('../functions.php');

display_edition();

?>
