<?php
require('../functions.php');

display_sample();

?>
