<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Hello World</title>
	<style type="text/css">
		body {
			background: #fff;
			color: #000;
			width: 384px;
			margin: 0px;
			padding: 20px 0px;
		}
		h1 {
			word-wrap: break-word;
			font-family: Arial, sans-serif;
		}
	</style>
</head>
<body>

	<h1><?php echo $greeting; ?></h1>

</body>
</html>
