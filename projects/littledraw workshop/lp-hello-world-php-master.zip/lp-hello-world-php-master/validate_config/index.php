<?php
require('../functions.php');

display_validate_config();

?>
